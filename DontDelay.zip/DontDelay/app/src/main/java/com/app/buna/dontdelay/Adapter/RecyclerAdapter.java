package com.app.buna.dontdelay.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.app.buna.dontdelay.R;
import com.app.buna.dontdelay.common.ToDoData;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {
    private ArrayList<ToDoData> mDataset;
    private Context context;

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        private TextView toDoTextView;
        private TextView toDoDDay;
        private TextView priorityTextView;
        private LinearLayout priorityLayout;
        private ImageView alarmImageView;
        private TextView placeTextView;
        private ImageView placeImageView;

        private MyViewHolder(View v) {
            super(v);
            View view = v;

            toDoTextView = (TextView) v.findViewById(R.id.to_do_text);
            toDoDDay = (TextView) v.findViewById(R.id.time_text_view);
            alarmImageView = (ImageView) v.findViewById(R.id.change_order_image_view);
            placeTextView = (TextView) v.findViewById(R.id.place_text_view);
            placeImageView = (ImageView) v.findViewById(R.id.place_image_view);
            /*priorityTextView = (TextView) v.findViewById(R.id.priority_text_view);        // 추후 everyfragment에서 우선순위 사용할 때 C/P
            priorityLayout = v.findViewById(R.id.priority_layout);*/

        }
    }


    public RecyclerAdapter(ArrayList<ToDoData> myDataset, Context context) {
        mDataset = myDataset;
        this.context = context;
    }


    @Override
    public RecyclerAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                     int viewType) {
        // create a new view
        View v = (View) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.dday_schedule, parent, false);

        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }


    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        String dDayString = dDayString(position);

        holder.toDoTextView.setText(mDataset.get(position).getToDoContent());
        holder.toDoDDay.setText(dDayString);
        /*holder.priorityTextView.setText(Integer.toString(mDataset.get(position).getPriority()));      // 추후 everyfragment에서 우선순위 사용할 때 C/P
        setColorLayout(context, holder.priorityLayout, holder.priorityTextView, mDataset.get(position).getPriority());    // priority에 따른 색상 설정*/
    }



    @Override
    public int getItemCount() {
        return mDataset.size();
    }



    /* my methods */

    private String dDayString(int position) {
        String dDay = "· D";

        int dDayInt = mDataset.get(position).getdDay();
        if(dDayInt == 0){
            dDay = "· Today!";
        }else {
            if(dDayInt < 0) {
                dDay += " + " + Integer.toString(dDayInt * -1) + " day";
            } else
                dDay += " - " + Integer.toString(dDayInt) + " day";
        }

        return dDay;
    }

    private void setAlarmImage(ImageView alarmImage, int alarmCheck) {
        if(alarmCheck == 1) {
            alarmImage.setImageResource(R.drawable.clock);
        }else if(alarmCheck == 0){
            alarmImage.setImageResource(R.drawable.no_clock);
        }
    }

    private void setPlaceImage(ImageView placeImage, String place) {
        switch (place) {
            case "가정":
                placeImage.setImageResource(R.drawable.home);
                break;
            case "학교":
                placeImage.setImageResource(R.drawable.school);
                break;
            case "직장":
                placeImage.setImageResource(R.drawable.workspace);
                break;
            case "종교":
                placeImage.setImageResource(R.drawable.church);
                break;
            case "식당":
                placeImage.setImageResource(R.drawable.restaurant);
                break;
            case "카페":
                placeImage.setImageResource(R.drawable.cafe);
                break;
            case "병원":
                placeImage.setImageResource(R.drawable.hospital);
                break;
            case "기타":
                placeImage.setImageResource(R.drawable.etc);
                break;

        }
    }

    /*private void setColorLayout(Context context, LinearLayout linearLayout, TextView textView, int priority) {

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {

            switch (priority) {
                case 1:
                    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) textView.getLayoutParams();
                    layoutParams.topMargin = 1;
                    linearLayout.setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.custom_first_priority));
                    break;
                case 2:
                    linearLayout.setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.custom_second_priority));
                    break;
                case 3:
                    linearLayout.setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.custom_third_priority));
                    break;
                case 4:
                    linearLayout.setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.custom_fourth_priority));
                    break;
                case 5:
                    linearLayout.setBackgroundDrawable(ContextCompat.getDrawable(context, R.drawable.custom_fifth_priority));
                    break;
            }
        }

    }*/

}