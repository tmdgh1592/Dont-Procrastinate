package com.app.buna.dontdelay.common;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;

import com.app.buna.dontdelay.Activity.EditActivty;
import com.app.buna.dontdelay.Activity.MainActivity;

import java.util.ArrayList;

public class GoEditActivity {
    int position, CODE;
    Context context;
    MainActivity mainActivity;
    ArrayList<ToDoData> mDataset;

    public GoEditActivity(MainActivity mainActivity, ArrayList<ToDoData> mDataset, int position, int CODE, Context context){
        this.position = position;
        this.CODE = CODE;
        this.context = context;
        this.mainActivity = mainActivity;
        this.mDataset = mDataset;
    }

    public void goToEditActivity(){

            if(mainActivity.isSoftKeyboardShown() || position == 0){
                return;
            }
            ToDoData data = mDataset.get(position);
            Intent intent = new Intent(context, EditActivty.class);

            //old Data
            intent.putExtra("content", data.getToDoContent()); // [String] format : content
            intent.putExtra("favorite", data.getIsFavroite());
            intent.putExtra("memo", data.getMemo());
            intent.putExtra("toDoDay", data.getToDoDay());
            intent.putExtra("createTime", data.getCreated());
            intent.putExtra("repeatMonth", data.getRepeatMonth());
            intent.putExtra("repeatDate", data.getRepeatDate());
            intent.putExtra("repeatDow", data.getRepeatDow());
            intent.putExtra("howRepeat", data.getHowRepeat());
            intent.putExtra("repeatText", data.getRepeatText());
            intent.putExtra("alarmYear", data.getAlarmYear());
            intent.putExtra("alarmMonth", data.getAlarmMonth());
            intent.putExtra("alarmDate", data.getAlarmDate());
            intent.putExtra("alarmHour", data.getAlarmHour());
            intent.putExtra("alarmMin", data.getAlarmMin());
            intent.putExtra("isClear", data.getIsClear());
            intent.putExtra("howRepeatUnit", data.getHowRepeatUnit());
            intent.putExtra("forSeparatingCreated", data.getForSeparatingCreated());
            // DB 특정 조건 값 전송 => editactivity에서 update, where문으로 쿼리값 수정
            mainActivity.startActivityForResult(intent, CODE);
        }
    }
