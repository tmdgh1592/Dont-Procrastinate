package com.app.buna.dontdelay.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.ImageView;

import com.app.buna.dontdelay.R;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CalendarActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private ImageView closeImageView;
    private ImageView saveImageView;
    private int mYear = 2019, mMonth = 01, mDayOfMonth = 01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender);

        saveImageView = findViewById(R.id.save_button);
        closeImageView = findViewById(R.id.close_button);

        closeImageView.setOnClickListener(clickListener);
        saveImageView.setOnClickListener(clickListener);


        calendarView = findViewById(R.id.calendar_view);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int dayOfMonth) {
                mYear = year;
                mMonth = month;
                mDayOfMonth = dayOfMonth;
            }
        });
        setCalendarView();



    }

    private void setCalendarView() {

    }

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            Intent intent = new Intent();

            switch (view.getId()){ // 날짜 데이터 전송 부분
                case R.id.save_button:
                    int year = mYear, month = mMonth, day = mDayOfMonth;
                    intent.putExtra("year", year);
                    intent.putExtra("month", month);
                    intent.putExtra("day", day);
                    setResult(RESULT_OK, intent);
                    finish();
                    break;

                case R.id.close_button:
                    finish();
                    break;
            }
        }
    };

}

