package com.app.buna.dontdelay.common;

public class ViewTypeVO {

    public static final int VIEW_TYPE_ITEM = 0;
    public static final int VIEW_TYPE_ITEM2 = 2;
    public static final int VIEW_TYPE_TITLE = 1;

}
