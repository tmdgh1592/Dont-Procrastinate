package com.app.buna.dontdelay.Activity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.app.buna.dontdelay.R;
import com.app.buna.dontdelay.common.DBHelper;
import com.app.buna.dontdelay.common.DayManager;
import com.app.buna.dontdelay.common.MyTextWatcher;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AddActivity extends AppCompatActivity {

    private final int ADD_ACTIVITY_CODE = 3210;

    private EditText toDoEditText;
    private ImageView cancelImage;
    private TextView inputCountText;
    private RadioGroup radioGroup;
    private ImageView closeImage;
    private LinearLayout toDoDayLayout;
    private TextView toDoDayTextView;
    private String mYear = "2019", mMonth = "08", mDay = "01";
    private String dateFormat = mYear + " - " + mMonth + " - " + mDay;
    private String mSec;
    private RelativeLayout saveButton;
    //private int priority = 1;
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    private SimpleDateFormat secSdf = new SimpleDateFormat("ss");
    private Spinner mySpinner;
    private Switch mySwitch;
    private int alarmCheck = 0;
    private String toDoplace = "장소 선택";
    private int isClear = 0;
    private DatePickerDialog datePickerDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dday_add);
        initialize();

    }


    private void initialize(){
        String today = sdf.format(new Date());
        mSec = secSdf.format(new Date()).split("-")[0];
        mYear = today.split("-")[0];
        mMonth = today.split("-")[1];
        mDay = today.split("-")[2];
        dateFormat = mYear + " - " + mMonth + " - "  + mDay;

        inputCountText = (TextView) findViewById(R.id.input_count_text_view);
        toDoDayTextView = findViewById(R.id.to_do_day_text_view);
        closeImage = findViewById(R.id.activity_close_image_view);
        saveButton = (RelativeLayout) findViewById(R.id.save_button);
        saveButton.setOnClickListener(clickListener);

        toDoEditText = (EditText) findViewById(R.id.to_do_edit_text);
        toDoEditText.addTextChangedListener(new MyTextWatcher(inputCountText, toDoEditText));

        //enter key 방지
        toDoEditText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int keyCode, KeyEvent keyEvent) {
                if(keyCode == KeyEvent.KEYCODE_ENTER){
                    return true;
                }
                return false;
            }
        });
        cancelImage = (ImageView) findViewById(R.id.edit_cancel_image_view);
        cancelImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { // edit_text 입력내용 지우기
                toDoEditText.setText("");
            }
        });

        closeImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        //radioGroup = findViewById(R.id.radio_group);
        //setPriority(radioGroup);

        toDoDayLayout = findViewById(R.id.to_do_day_layout);
        toDoDayTextView.setText(dateFormat);
        toDoDayLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), CalendarActivity.class);
                startActivityForResult(intent, ADD_ACTIVITY_CODE);
/*                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    datePickerDialog = new DatePickerDialog(getApplicationContext(), datePickerListener, Integer.parseInt(mYear), Integer.parseInt(mMonth), Integer.parseInt(mDay));
                    datePickerDialog.show();
                }*/
            }
        });

        mySwitch = findViewById(R.id.my_switch);
        mySpinner = findViewById(R.id.my_spinner);

        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked) {
                    alarmCheck = 1;
                }else {
                    alarmCheck = 0;
                }
            }
        });

        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                toDoplace = adapterView.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }

    public void sendDataToIntent(Intent intent){

        String toDoContent = toDoEditText.getText().toString();
        String toDoDay = mYear + "-" + mMonth + "-" + mDay;
        //int priority = this.priority;
        Bundle mBundle = new Bundle();


        mBundle.putString("content", toDoContent);
        mBundle.putString("dayString", toDoDay);
        //mBundle.putInt("priority", priority);
        mBundle.putInt("year", Integer.parseInt(mYear));
        mBundle.putInt("month", Integer.parseInt(mMonth));
        mBundle.putInt("day", Integer.parseInt(mDay));
        mBundle.putString("sec", mSec);
        mBundle.putString("place", toDoplace);
        mBundle.putInt("alarmCheck", alarmCheck);

        //saveDataOnDB(toDoContent, toDoDay, dDay, mYear, mMonth, mDay, mSec, toDoplace, alarmCheck, isClear); // insert into database
        intent.putExtras(mBundle);
    }

    private void saveDataOnDB(String content, String day, int dDay, String year, String month, String _day, String mSec, String place, int alarmCheck, int isClear) {

        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL("INSERT INTO todo_table (content, day, dday, year, month, _day, sec, place, alarmcheck, isclear) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                new String[] {content, day, Integer.toString(dDay), year, month, _day, mSec, place, Integer.toString(alarmCheck), Integer.toString(isClear)});

        db.close();

    }





    /* 저장버튼 누를 때 이벤트 */

    private View.OnClickListener clickListener = new View.OnClickListener() {

        Intent intent = new Intent();
        @Override
        public void onClick(View view) {
            switch (view.getId()){
                case R.id.save_button:
                    if(toDoEditText.equals("") || toDoEditText.length() < 1) {
                        Toast.makeText(AddActivity.this, getString(R.string.toDoNull), Toast.LENGTH_SHORT).show();
                        break;
                    }else if(toDoplace.equals("장소 선택")){
                        Toast.makeText(AddActivity.this, getString(R.string.toPlaceNull), Toast.LENGTH_SHORT).show();
                        break;
                    }else {
                        sendDataToIntent(intent);
                        setResult(RESULT_OK, intent);
                        finish();
                    }
            }
        }
    };


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        DayManager dayManager = new DayManager();

        if(resultCode == RESULT_OK) {
            switch (requestCode) {
                case ADD_ACTIVITY_CODE:
                    String orderedMonth = dayManager.getAddNumMonth(data.getIntExtra("month", 00));
                    String orderedDay = dayManager.getAddNumDay(data.getIntExtra("day", 01));

                    mYear = Integer.toString(data.getIntExtra("year", 2019));
                    mMonth = orderedMonth + Integer.toString(data.getIntExtra("month", 00) + 1); // month는 + 1 해줘야함
                    mDay = orderedDay + Integer.toString(data.getIntExtra("day", 01));
                    dateFormat = mYear + " - " + mMonth + " - " + mDay;
                    toDoDayTextView.setText(dateFormat);
                    break;

                default:
                    break;
            }
        }

    }

    private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            mYear = Integer.toString(year);
            mMonth = Integer.toString(month);
            mDay = Integer.toString(dayOfMonth);
        }
    };


    /*public void setPriority(RadioGroup radioGroup) {

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int res) {

                switch (res){
                    case R.id.radio_button_1:
                        priority = 1;
                        break;
                    case R.id.radio_button_2:
                        priority = 2;
                        break;
                    case R.id.radio_button_3:
                        priority = 3;
                        break;
                    case R.id.radio_button_4:
                        priority = 4;
                        break;
                    case R.id.radio_button_5:
                        priority = 5;
                        break;
                    default:
                        Toast.makeText(AddActivity.this, "Null", Toast.LENGTH_SHORT).show();
                        break;

                }
            }
        });
    }*/

    }
