package com.app.buna.dontdelay.common;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;

import androidx.core.app.NotificationManagerCompat;

import com.app.buna.dontdelay.Activity.MainActivity;
import com.app.buna.dontdelay.R;

public class BroadCastD extends BroadcastReceiver {

    String INTENT_ACTION = Intent.ACTION_BOOT_COMPLETED;

    @Override
    public void onReceive(Context context, Intent intent) {

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, new Intent(context, MainActivity.class), PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder = new Notification.Builder(context);

        Notification.BigTextStyle style = new Notification.BigTextStyle(builder);
        style.setSummaryText("푸시 알림 도착").setBigContentTitle("앱을 클릭하여 오늘 할 일을 확인하세요!").setBigContentTitle("할 일 제목");

        builder.setSmallIcon(R.drawable.alarm_icon).setTicker("미루지마 - 푸시 알림이 도착했습니다.").setWhen(System.currentTimeMillis())
                .setNumber(1).setStyle(style).setContentText("앱을 클릭하여 오늘 할 일을 확인하세요!")
                .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE).setContentIntent(pendingIntent).setAutoCancel(true)
                .setWhen(System.currentTimeMillis()).setOngoing(false);


        notificationManager.notify(0, builder.build());

        //notification 삭제
        //NotificationManagerCompat.from(context).cancel(0);

    }
}
