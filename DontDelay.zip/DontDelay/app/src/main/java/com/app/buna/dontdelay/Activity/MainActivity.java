package com.app.buna.dontdelay.Activity;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationManagerCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.app.buna.dontdelay.Adapter.NotDoneRecyclerAdapter;
import com.app.buna.dontdelay.R;
import com.app.buna.dontdelay.common.AlarmHATT;
import com.app.buna.dontdelay.common.BackPressEditText;
import com.app.buna.dontdelay.common.DBHelper;
import com.app.buna.dontdelay.common.DOWManger;
import com.app.buna.dontdelay.common.DayManager;
import com.app.buna.dontdelay.common.MyTextWatcher;
import com.app.buna.dontdelay.common.ToDoData;
import com.github.jjobes.slidedatetimepicker.SlideDateTimeListener;
import com.github.jjobes.slidedatetimepicker.SlideDateTimePicker;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.shrikanthravi.customnavigationdrawer2.widget.SNavigationDrawer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

import static com.app.buna.dontdelay.common.ViewTypeVO.VIEW_TYPE_ITEM;
import static com.app.buna.dontdelay.common.ViewTypeVO.VIEW_TYPE_TITLE;


public class MainActivity extends AppCompatActivity {


    SharedPreferences setting;
    SharedPreferences.Editor editor;

    private DrawerLayout drawerLayout;

    /* activity_drawer */
    private View drawerView;
    private ImageView profileImageView;

    private ViewPager mViewPager;
    private PagerAdapter mPagerAdapter;
    private Context mContext;
    private TabLayout mTabLayout;
    private View todayScheduleView;
    private LinearLayout todoLinearLayout, addLinearLayout, writeOkLayout
            ,firstMenuLayout, secondMenuLayout, thirdMenuLayout, topLayout, notDoneView;
    private RelativeLayout backgroundLayout;

    private DOWManger dowManger;
    StringBuilder dowStringBuilder = new StringBuilder();

    public RecyclerView notDoneRecyclerView;
    private RecyclerView.Adapter notDoneAdapter;

    private Animation addViewAnimation;

    private AppBarLayout appBarLayout;

    private RecyclerView.LayoutManager layoutManager;
    public ArrayList<ToDoData> notDoneDataset = new ArrayList<>();
    public ArrayList<ToDoData> doneDataset = new ArrayList<>();
    private ArrayList<String> toDoDayList = new ArrayList<>();

    private ItemTouchHelper itemTouchHelper;

    private TextView firstMenuTextView, secondMenuTextView, thirdMenuTextView;

    private FloatingActionButton fab;
    private InputMethodManager imm;
    private BackPressEditText enterToDoEditText;
    private ImageView writeOkImageView, favoriteImageView, backgroundImageView;

    private TabLayout tabLayout;
    private View dialogView;
    private ViewPager viewPager;
    private PagerAdapter pagerAdapter;

    DayManager dayManager;

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    private String todayYear, todayMonth, todayDay, toDoContent = "";

    private CheckBox monCB, tueCB, wedCB, thurCB, friCB, satCB, sunCB;

    private Spinner howRepeatSpinner;
    private EditText howRepeatEditText;

    String[] weekDay = { "일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일" };

    private boolean isKeyBoardView = false;
    private boolean isFavorite = false;
    private PopupMenu popupMenu;
    public final int REQUEST_TO_EDIT_ACTIVITY_CODE = 3300;
    private Toolbar toolbar;

    private View howRepeatView;

    AlertDialog.Builder builder;
    AlertDialog howRepeatDialog;

    private int editPosition, howRepeatUnit = 1, howRepeatDayInt = 0;

    private CollapsingToolbarLayout collapsingToolbarLayout;

    private String todayDayOfWeek, tomorrowDayOfWeek, nextWeekDayOfWeek, calendarDayOfWeek;     // 일정 deadline
    private String selectedYear = "", selectedMonth = "", selectedDay = "";                                    // 일정 일자
    private String howRepeat = "", howRepeatDayString = "";
    private String alarmHour = "", alarmMin = "";                                                         // 알림 시간
    private String alarmYear ="", alarmMonth="", alarmDate="";
    private String repeatMonth = "", repeatDay = "", repeatDow = "", repeatText = "";                                      // 반복 월, 일, 요일
    private String memo = "";
    private String forSeparatingCreated = "";

    private boolean isDaySet = false;
    private boolean isRepeatSet = false;
    private boolean isAlarmSet = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setting = getSharedPreferences("setting", 0);
        editor = setting.edit();

        drawerLayout = (DrawerLayout)findViewById(R.id.drawer_layout);
        drawerView = (View)findViewById(R.id.drawer);
        drawerLayout.setDrawerListener(drawerListener);
        drawerView.setOnTouchListener(touchListener);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        topLayout = findViewById(R.id.top_layout);
        topLayout.setOnTouchListener(touchListener);

        collapsingToolbarLayout = findViewById(R.id.collapsingToolbarLayout01);

        howRepeatView = getLayoutInflater().inflate(R.layout.custom_how_repeat_dialog, null);

        loadCheckBox();
        loadAndSetListenerMenuLayout();


        favoriteImageView = findViewById(R.id.favorite_image_view);
        favoriteImageView.setOnTouchListener(touchListener);

        dayManager = new DayManager();



        firstMenuTextView = findViewById(R.id.first_menu_text_view);
        secondMenuTextView = findViewById(R.id.second_menu_text_view);
        thirdMenuTextView = findViewById(R.id.third_menu_text_view);

        howRepeatEditText = howRepeatView.findViewById(R.id.how_repeat_edit_text);
        howRepeatSpinner = howRepeatView.findViewById(R.id.how_repeat_spinner);
        howRepeatSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {   // 여기
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                LinearLayout layout = howRepeatView.findViewById(R.id.day_select_layout);
                switch (position) {
                    case 0:
                        howRepeatUnit = 1;
                        initCheckBox();
                        toDoDayList.clear();
                        layout.setVisibility(View.GONE);
                        layout.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.day_select_layout_invisible));
                        break;
                    case 1:
                        howRepeatUnit = 7;
                        initCheckBox();
                        toDoDayList.clear();
                        layout.setVisibility(View.VISIBLE);
                        layout.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.day_select_layout_visible));
                        break;
                    case 2:
                        howRepeatUnit = 30;
                        initCheckBox();
                        toDoDayList.clear();
                        layout.setVisibility(View.GONE);
                        layout.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.day_select_layout_invisible));
                        break;
                    case 3:
                        howRepeatUnit = 365;
                        initCheckBox();
                        toDoDayList.clear();
                        layout.setVisibility(View.GONE);
                        layout.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.day_select_layout_invisible));
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Log.d("LogD", "onNothingSelected: nothing selected");
            }
        });


        writeOkLayout = findViewById(R.id.write_ok_layout);

        enterToDoEditText = findViewById(R.id.add_edit_text);
        enterToDoEditText.setOnBackPressListener(onBackPressListener);
        MyTextWatcher editTextWatcher = new MyTextWatcher(enterToDoEditText);
        enterToDoEditText.addTextChangedListener(editTextWatcher);
        writeOkImageView = findViewById(R.id.write_ok_image_view);
        editTextWatcher.setResource(getResources(), writeOkImageView, writeOkLayout);
        enterToDoEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                switch (actionId) {
                    case EditorInfo.IME_ACTION_DONE:
                        if(enterToDoEditText.getText().length() == 0) {
                            return true;
                        }else if(enterToDoEditText.getText().length() > 0) {
                            hideAddLayout(); // 이 곳에 추가하는 메소드 삽입 ***
                        }
                }
                return true;
            }
        });

        mContext = getApplicationContext();


        /*mTabLayout = (TabLayout) findViewById(R.id.layout_tab);
        mTabLayout.addTab(mTabLayout.newTab().setCustomView(createTabView("오늘 할 일".toString(),0)));
        mTabLayout.addTab(mTabLayout.newTab().setCustomView(createTabView("D - Day".toString(), 1)));
        mTabLayout.addTab(mTabLayout.newTab().setCustomView(createTabView("매일&습관".toString(), 2)));
        mTabLayout.addTab(mTabLayout.newTab().setCustomView(createTabView("캘린더", 3)));

        mViewPager = (ViewPager) findViewById(R.id.pager_content);
        mPagerAdapter = new com.app.buna.dontdelay.Adapter.PagerAdapter(getSupportFragmentManager(), mTabLayout.getTabCount());
        mViewPager.setAdapter(mPagerAdapter);
        mViewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(mTabLayout));
        mTabLayout.addOnTabSelectedListener(tabListener);*/

        todayScheduleView = LayoutInflater.from(this).inflate(R.layout.dday_schedule,null);
        todoLinearLayout = todayScheduleView.findViewById(R.id.to_do_linearlayout);
        todoLinearLayout.setClickable(true);
        todoLinearLayout.setOnClickListener(clickListener);

        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        addLinearLayout = findViewById(R.id.add_linear_layout);

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(clickListener);
        writeOkImageView.setOnClickListener(clickListener);

        new AlarmHATT(getApplicationContext()).Alarm();

        todayYear = sdf.format(new Date()).split("-")[0];
        todayMonth = sdf.format(new Date()).split("-")[1];
        todayDay = sdf.format(new Date()).split("-")[2];


        /* 진행중 recyclerview */

        itemTouchHelper = new ItemTouchHelper(touchHelperCallback);
        //itemTouchHelper.attachToRecyclerView(notDoneRecyclerView);

        notDoneRecyclerView = (RecyclerView) findViewById(R.id.not_done_recycler_view);
        notDoneRecyclerView.setHasFixedSize(true);

        builder = new AlertDialog.Builder(MainActivity.this);


        builder.setView(howRepeatView)
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {

                    }
                })
                .setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        initCheckBox();
                    }
                });

        howRepeatDialog = builder.create();
        howRepeatDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                Button posBtn = howRepeatDialog.getButton(AlertDialog.BUTTON_POSITIVE);
                Button negBtn = howRepeatDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
                negBtn.setTextColor(Color.GRAY);
                posBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        howRepeatDayString = Integer.toString(howRepeatDayInt = (Integer.parseInt(howRepeatEditText.getText().toString()) * howRepeatUnit));
                        howRepeat = "CALENDAR";
                        thirdMenuTextView.setTextSize(12);
                        addToDoDOWToArrayList();
                        Iterator<String> iterator = toDoDayList.iterator();
                        while(iterator.hasNext()){
                            dowStringBuilder.append(iterator.next());      // 나중에 split("요일")로 끊어주기
                        }
                        repeatDow = dowStringBuilder.toString();
                        if(howRepeatEditText.getText().toString().equals("0")) {
                            Toast.makeText(mContext, "0보다 크게 입력해주세요.", Toast.LENGTH_SHORT).show();
                            toDoDayList.clear();
                        }else if(howRepeatUnit == 7 && toDoDayList.isEmpty()) {
                            Toast.makeText(mContext, "요일을 선택해주세요.", Toast.LENGTH_SHORT).show();
                            toDoDayList.clear();
                        }else {
                            setThirdTextView();
                            initCheckBox();
                            repeatText = howRepeatEditText.getText().toString();
                            thirdMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
                            howRepeatDialog.dismiss();
                            isRepeatSet = true;
                        }
                    }
                });
                negBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        toDoDayList.clear();
                        howRepeatDialog.cancel();
                    }
                });
            }
        });
        howRepeatDialog.setCanceledOnTouchOutside(false);



        notDoneRecyclerView.addOnItemTouchListener(new RecyclerTouchListener(getApplicationContext(),
                notDoneRecyclerView, new ClickListener() {
            @Override
            public void onClick(View view, int position) {

            }

            @Override
            public void onLongClick(View view, int position) {          /* item 꾹 눌렀을 때 */

            }
        }));


        layoutManager = new LinearLayoutManager(this);
        notDoneRecyclerView.setLayoutManager(layoutManager);

        notDoneAdapter = new NotDoneRecyclerAdapter(notDoneDataset, this, getResources(), this);
        notDoneRecyclerView.setAdapter(notDoneAdapter);
        //setViewAsTime();
        NotificationManagerCompat.from(MainActivity.this).cancelAll();

    }


    @SuppressWarnings("deprecation")
    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    public boolean isSoftKeyboardShown() {
        if((drawerLayout) == null) return false;

        int height = drawerLayout.getMeasuredHeight();
        Activity activity = (Activity) MainActivity.this;
        Rect rect = new Rect();
        activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        int statusBarHeight = rect.top;

        int screenHeight;
        if(Build.VERSION.SDK_INT <= Build.VERSION_CODES.HONEYCOMB_MR2) {
            Point p = new Point();
            activity.getWindowManager().getDefaultDisplay().getSize(p);
            screenHeight = p.y;
        }
        else {
            screenHeight = activity.getWindowManager().getDefaultDisplay().getHeight();
        }

        int diff = (screenHeight - statusBarHeight) - height;

        return (diff>200);// assume all soft keyboards are at least 128 pixels high
    }





      /*                     */
     /*   listener methods  */
    /*                     */


    private BackPressEditText.OnBackPressListener onBackPressListener = new BackPressEditText.OnBackPressListener() {

        @Override
        public void onBackPress() {
            initSettings();
            hideAddLayout();
            initCheckBox();
        }
    };


    // 시간대 별로 배경 바꾸는 코드

    /*private void setViewAsTime() {

        SimpleDateFormat sdf = new SimpleDateFormat("HH");
        int nowHour = Integer.parseInt(sdf.format(new Date()));
        Toast.makeText(mContext, Integer.toString(nowHour), Toast.LENGTH_SHORT).show();

        backgroundImageView = findViewById(R.id.background_image_view);
        backgroundLayout = findViewById(R.id.background_layout);

        Toast.makeText(mContext, Integer.toString(nowHour), Toast.LENGTH_SHORT).show();

        if(7 <= nowHour && nowHour <= 16) {  // 아침 배경 설정
            backgroundImageView.setBackgroundResource(R.drawable.morning_background);
            backgroundLayout.setBackgroundColor(ContextCompat.getColor(this, R.color.white));
            getWindow().setStatusBarColor(Color.RED);
            collapsingToolbarLayout.setContentScrimColor(Color.GREEN);
        } else if((17 <= nowHour && nowHour <= 20) || (5 <= nowHour && nowHour <= 6)){ // 해질녘, 새벽 배경 설정
            backgroundImageView.setBackgroundResource(R.drawable.evening_background);
            backgroundLayout.setBackgroundColor(ContextCompat.getColor(this, R.color.nightBackgroundColor2));
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.nightBackgroundColor));
            collapsingToolbarLayout.setContentScrimColor(ContextCompat.getColor(this, R.color.nightBackgroundColor));
        } else { // 밤 배경 설정
            backgroundImageView.setBackgroundResource(R.drawable.night_background);
            backgroundLayout.setBackgroundColor(ContextCompat.getColor(this, R.color.nightBackgroundColor));
            getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.nightBackgroundColor));
            collapsingToolbarLayout.setContentScrimColor(ContextCompat.getColor(this, R.color.nightBackgroundColor));
        }


    }*/

    public TabLayout.OnTabSelectedListener tabListener = new TabLayout.OnTabSelectedListener(){
        @Override
        public void onTabSelected(TabLayout.Tab tab) {
            viewPager.setCurrentItem(tab.getPosition());

        }

        @Override
        public void onTabUnselected(TabLayout.Tab tab) {

        }

        @Override
        public void onTabReselected(TabLayout.Tab tab) {

        }
    };


    private void initializeDrawerView() {
        profileImageView = findViewById(R.id.profile);
        profileImageView.setBackground(new ShapeDrawable(new OvalShape()));
        profileImageView.setClipToOutline(true);
    }

    private View.OnClickListener clickListener = new View.OnClickListener() {
        @SuppressLint("RestrictedApi")
        @Override
        public void onClick(View view) {

            popupMenu = new PopupMenu(getApplicationContext(), view);
            popupMenu.setOnMenuItemClickListener(onMenuItemClickListener);

            switch (view.getId()){
                case R.id.to_do_linearlayout:
                    TextView textView = view.findViewById(R.id.to_do_text);
                    break;
                case R.id.first_menu_layout:
                    getMenuInflater().inflate(R.menu.add_first_menu, popupMenu.getMenu());
                    todayDayOfWeek = setDeadlineDOW("오늘");
                    tomorrowDayOfWeek = setDeadlineDOW("내일");
                    nextWeekDayOfWeek = setDeadlineDOW("다음주");
                    popupMenu.getMenu().add(Menu.NONE, 1,0,"오늘 (" + todayDayOfWeek + ")");  //groupId, itemId, order, title
                    popupMenu.getMenu().add(Menu.NONE, 2,1,"내일 (" + tomorrowDayOfWeek + ")");
                    popupMenu.getMenu().add(Menu.NONE, 3,2,"다음 주 (" + nextWeekDayOfWeek + ")");
                    popupMenu.getMenu().add(Menu.NONE, 4,3,"날짜 선택");
                    popupMenu.show();
                    break;
                case R.id.second_menu_layout:
                    getMenuInflater().inflate(R.menu.add_second_menu, popupMenu.getMenu());
                    popupMenu.show();
                    break;
                case R.id.third_menu_layout:
                    getMenuInflater().inflate(R.menu.add_third_menu, popupMenu.getMenu());
                    toDoDayList.clear();
                    popupMenu.show();
                    break;
                case R.id.fab:
                    initAddView();
                    enterToDoEditText.requestFocus();
                    isKeyBoardView = true;
                    initSettings();

                    fab.setVisibility(View.GONE);
                    fab.setAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_invisible));

                    appBarLayout = findViewById(R.id.app_bar_layout);
                    appBarLayout.setExpanded(false);
                    if(addLinearLayout.getVisibility() == View.GONE) {
                        addLinearLayout.setVisibility(View.VISIBLE);
                    }

                    Thread visibleThread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            imm.showSoftInput(enterToDoEditText, 0);
                        }
                    });
                    visibleThread.start();
/*                    addViewAnimation = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.add_layout_visible);
                    addLinearLayout.startAnimation(addViewAnimation);*/

                    selectedYear = todayYear;
                    selectedMonth = todayMonth;
                    selectedDay = todayDay;

                    firstMenuLayout.setBackgroundResource(R.drawable.custom_unsetting_layout);
                    secondMenuLayout.setBackgroundResource(R.drawable.custom_unsetting_layout);
                    thirdMenuLayout.setBackgroundResource(R.drawable.custom_unsetting_layout);

                    break;
                case R.id.write_ok_image_view:
                    if(enterToDoEditText.getText().length() != 0) { // 할 일 입력칸이 비어있지 않은 경우
                        if(isAlarmSet == false || isDaySet == false || isRepeatSet == false) {  // 알람, 일자, 반복 모두 설정했을 때
                            Toast.makeText(mContext, getString(R.string.alertAboutUnSet), Toast.LENGTH_SHORT).show();
                            return;
                        }else{  // 알람, 일정날짜, 반복설정이 모두 돼 있는 경우
                            toDoContent = enterToDoEditText.getText().toString();

                            forSeparatingCreated = Long.toString(System.currentTimeMillis());

                            dbInsert(toDoContent, isFavorite, selectedYear + "-" + selectedMonth + "-" + selectedDay,
                                    dowStringBuilder.toString(),
                                    sdf.format(new Date()), howRepeat, false,
                                    alarmYear, alarmMonth, alarmDate, alarmHour, alarmMin, repeatText, Integer.toString(howRepeatUnit), memo, forSeparatingCreated);


                            /* 초기화 */
                            initSettings();
                            hideAddLayout();
                            onResume();
                        }
                    }
                default:
                    return;
            }
        }
    };


    PopupMenu.OnMenuItemClickListener onMenuItemClickListener = new PopupMenu.OnMenuItemClickListener() {
        @Override
        public boolean onMenuItemClick(MenuItem menuItem) {

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

            if(menuItem.getItemId() == 1) {     // 오늘 선택
                selectedYear = todayYear;
                selectedMonth = todayMonth;
                selectedDay = todayDay;
                firstMenuTextView.setText("오늘까지");
                firstMenuTextView.setTextSize(12);
                firstMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
                isDaySet = true;
                return true;
            }else if(menuItem.getItemId() == 2) {       // 내일 선택
                Calendar cal = Calendar.getInstance();
                cal.add(cal.DATE, 1);
                String dateStr = dateFormat.format(cal.getTime());
                selectedYear = dateStr.split("-")[0];
                selectedMonth = dateStr.split("-")[1];
                selectedDay = dateStr.split("-")[2];
                firstMenuTextView.setText("내일까지");
                firstMenuTextView.setTextSize(12);
                firstMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
                isDaySet = true;
                return true;
            }else if(menuItem.getItemId() == 3) {       // 일주일 후 선택
                Calendar cal = Calendar.getInstance();
                cal.add(cal.DATE, 7);
                String dateStr = dateFormat.format(cal.getTime());

                selectedYear = dateStr.split("-")[0];
                selectedMonth = dateStr.split("-")[1];
                selectedDay = dateStr.split("-")[2];

                firstMenuTextView.setText(selectedMonth + "월 " + selectedDay + "일 " + nextWeekDayOfWeek + "까지");
                firstMenuTextView.setTextSize(12);
                firstMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);

                isDaySet = true;
                return true;
            }else if(menuItem.getItemId() == 4) {       // 캘린더로 지정 선택
                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, dateSetListener,
                        Integer.parseInt(todayYear), Integer.parseInt(todayMonth) - 1, Integer.parseInt(todayDay));
                datePickerDialog.show();
                firstMenuTextView.setTextSize(12);

                return true;
            }else if(menuItem.getItemId() == R.id.alarm_midnight) {
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DATE, 1);
                String when = dateFormat.format(cal.getTime());
                alarmYear = when.split("-")[0];
                alarmMonth = when.split("-")[1];
                alarmDate = dayManager.getAddNumDay(Integer.parseInt(when.split("-")[2])) + Integer.parseInt(when.split("-")[2]);
                alarmHour = "24";
                alarmMin = "00";
                alarmTimeSet(alarmHour, alarmMin);
                secondMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
                secondMenuTextView.setTextSize(12);
                isAlarmSet = true;
                Toast.makeText(mContext, "다음 날 " + alarmHour + "시 " + alarmMin + "분 푸시알림", Toast.LENGTH_SHORT).show();
            }else if(menuItem.getItemId() == R.id.alarm_morning) {
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DATE, 1);
                String when = dateFormat.format(cal.getTime());
                alarmYear = when.split("-")[0];
                alarmMonth = when.split("-")[1];
                alarmDate = dayManager.getAddNumDay(Integer.parseInt(when.split("-")[2])) + Integer.parseInt(when.split("-")[2]);
                alarmHour = "08";
                alarmMin = "00";
                alarmTimeSet(alarmHour, alarmMin);
                secondMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
                secondMenuTextView.setTextSize(12);
                isAlarmSet = true;
                Toast.makeText(mContext, "다음 날 " + alarmHour + "시 " + alarmMin + "분 푸시알림", Toast.LENGTH_SHORT).show();
            }else if(menuItem.getItemId() == R.id.alarm_no){
                alarmHour = "";
                alarmMin = "";
                secondMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
                secondMenuTextView.setText("알림 안함");
                secondMenuTextView.setTextSize(12);
                isAlarmSet = true;
            }else if(menuItem.getItemId() == R.id.alarm_user_control) {
                /*TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this, timeSetListener, 12, 00, false);
                timePickerDialog.show();*/
                new SlideDateTimePicker.Builder(getSupportFragmentManager())
                        .setListener(slideDateTimeListener)
                        .setInitialDate(new Date())
                        .setMinDate(new Date())
                        .setTheme(SlideDateTimePicker.HOLO_LIGHT)
                        .build()
                        .show();

            } else if(menuItem.getItemId() == R.id.repeat_every_day) {          // howRepeat으로 구분
                howRepeat = "EVERYDAY";
                thirdMenuTextView.setText("매일 반복");
                thirdMenuTextView.setTextSize(12);
                thirdMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
                isRepeatSet = true;
            }else if(menuItem.getItemId() == R.id.repeat_every_week) {          // 매주 반복은 '요일 DOW' 저장 -> 불러올때 로직 : 오늘 요일 == 요일array에 있는지
                howRepeat = "EVERYWEEK";
                SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
                String DOW = sdf.format(new Date());
                DOW = getTranslatedKoreanDow(DOW, 1);
                repeatDow = DOW;
                thirdMenuTextView.setText(repeatDow + " 매주 반복");
                thirdMenuTextView.setTextSize(12);
                thirdMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
                isRepeatSet = true;
            }else if(menuItem.getItemId() == R.id.repeat_every_month) {     // 한달에 한번은 '일' 저장
                howRepeat = "EVERYMONTH";
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd");
                repeatMonth = "0"; repeatDay = simpleDateFormat.format(new Date());
                thirdMenuTextView.setText("매달 반복");
                thirdMenuTextView.setTextSize(12);
                thirdMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
                isRepeatSet = true;
            }else if(menuItem.getItemId() == R.id.repeat_user_control) {
                howRepeat = "CALENDAR";
                howRepeatDialog.show();
            }else if(menuItem.getItemId() == R.id.no_repeat) {
                howRepeat = "NOREPEAT";
                thirdMenuTextView.setText("반복 안함");
                thirdMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
                isRepeatSet = true;
            }
            return false;
        }
    };


    private DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
            selectedYear = Integer.toString(year);

            if(month+1 >= 10){
                selectedMonth = Integer.toString(month+1);
            }else if(month+1 < 10){
                selectedMonth = "0" + Integer.toString(month+1);
            }

            if(day >= 10){
                selectedDay = Integer.toString(day);
            }else if(day < 10){
                selectedDay = "0" + Integer.toString(day);
            }



            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE");
            calendarDayOfWeek = simpleDateFormat.format(new Date(year, month, day - 1));
            firstMenuTextView.setText(selectedMonth + "월 " + selectedDay + "일 " + getTranslatedKoreanDow(calendarDayOfWeek, 1) + "까지");
            firstMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
            isDaySet = true;
        }
    };


    private SlideDateTimeListener slideDateTimeListener = new SlideDateTimeListener() {

        @Override
        public void onDateTimeSet(Date date)
        {
            SimpleDateFormat tempFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
            SimpleDateFormat tempFormat2 = new SimpleDateFormat("EEEE");


            String thisDay = tempFormat.format(date);
            Calendar calendar = Calendar.getInstance();

            alarmYear = thisDay.split("-")[0];
            alarmMonth = thisDay.split("-")[1];
            alarmDate = thisDay.split("-")[2];
            alarmHour = thisDay.split("-")[3];
            alarmMin = thisDay.split("-")[4];

            secondMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
            if(Integer.parseInt(alarmYear) == calendar.get(Calendar.YEAR)){
                secondMenuTextView.setTextSize(11);
                secondMenuTextView.setText(alarmMonth+"월 " + alarmDate +"일 (" + getTranslatedKoreanDow(tempFormat2.format(date), 2) + ")" + "\n" + alarmHour+"시 " + alarmMin + "분 푸시알림");
            }else{
                secondMenuTextView.setTextSize(11);
                secondMenuTextView.setText(alarmYear +"년 " + alarmMonth+"월 " + alarmDate +"일" +"\n" + alarmHour+"시 " + alarmMin + "분 푸시알림");
            }
            secondMenuTextView.setLineSpacing(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 3.0f, getResources().getDisplayMetrics()), 1.0f);
            isAlarmSet = true;
        }

        @Override
        public void onDateTimeCancel()
        {
            // on canceled
        }
    };

    private TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {

            alarmHour = Integer.toString(hourOfDay);
            alarmMin = Integer.toString(minute);

            if(hourOfDay < 10) {
                alarmHour = "0" + alarmHour;
            }
            if(minute < 10) {
                alarmMin = "0" + alarmMin;
            }
            secondMenuTextView.setText(alarmHour + "시 " + alarmMin + "분에 푸시알림");
            secondMenuTextView.setTextSize(12);
            secondMenuLayout.setBackgroundResource(R.drawable.custom_setting_layout);
            isAlarmSet = true;
        }
    };


    private View.OnTouchListener touchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {

            switch (view.getId()) {
                case R.id.favorite_image_view:
                    if(motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                        if(!isFavorite) {       // 즐겨찾기 설정 안돼있는 경우
                            setClickedStar();
                        } else if(isFavorite) {     // 즐겨찾기 설정 돼있는 경우
                            setUnclikedStar();
                        }

                    }
                    break;
                case R.id.first_menu_layout:
                    firstMenuLayout.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.menus_layout_click));
                    break;
                case R.id.second_menu_layout:
                    secondMenuLayout.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.menus_layout_click));
                    break;
                case R.id.third_menu_layout:
                    thirdMenuLayout.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.menus_layout_click));
                    break;
                case R.id.top_layout:
                    return true;
                case R.id.drawer:
                    return true;
            }
            return false;
        }
    };

    public String getTranslatedKoreanDow(String DOW, int MODE) {

        switch (MODE){
            case 1:
                if(DOW.equals("Sunday") || DOW.equals("1") || DOW.equals("일요일")) {
                    return "일요일";
                }else if(DOW.equals("Monday") || DOW.equals("2") || DOW.equals("월요일")) {
                    return "월요일";
                }else if(DOW.equals("Tuesday") || DOW.equals("3") || DOW.equals("화요일")) {
                    return "화요일";
                }else if(DOW.equals("Wednesday") || DOW.equals("4") || DOW.equals("수요일")) {
                    return "수요일";
                }else if(DOW.equals("Thursday") || DOW.equals("5") || DOW.equals("목요일")) {
                    return "목요일";
                }else if(DOW.equals("Friday") || DOW.equals("6") || DOW.equals("금요일")) {
                    return "금요일";
                }else if(DOW.equals("Saturday") || DOW.equals("7") || DOW.equals("토요일")) {
                    return "토요일";
                }else {
                    return "NULL";
                }
            case 2:
                if(DOW.equals("Sunday") || DOW.equals("1") || DOW.equals("일요일")) {
                    return "일";
                }else if(DOW.equals("Monday") || DOW.equals("2") || DOW.equals("월요일")) {
                    return "월";
                }else if(DOW.equals("Tuesday") || DOW.equals("3") || DOW.equals("화요일")) {
                    return "화";
                }else if(DOW.equals("Wednesday") || DOW.equals("4") || DOW.equals("수요일")) {
                    return "수";
                }else if(DOW.equals("Thursday") || DOW.equals("5") || DOW.equals("목요일")) {
                    return "목";
                }else if(DOW.equals("Friday") || DOW.equals("6") || DOW.equals("금요일")) {
                    return "금";
                }else if(DOW.equals("Saturday") || DOW.equals("7") || DOW.equals("토요일")) {
                    return "토";
                }else {
                    return "NULL";
                }
            default:
                return "NULL";
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.popup_menu, menu);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                drawerLayout.openDrawer(drawerView);
                break;
            case R.id.item_menu1:   // 위젯 만들기
                Toast.makeText(mContext, "test1", Toast.LENGTH_SHORT).show();
                break;
            case R.id.item_menu2:   // 테마 변경
                Toast.makeText(mContext, "test2", Toast.LENGTH_SHORT).show();
                break;
            case R.id.item_menu3:   // 완료 작업 보기
                Toast.makeText(mContext, "test3", Toast.LENGTH_SHORT).show();
                break;
            case R.id.sort1:   // 정렬 기준 : 중요도
                editor.remove("sort");
                editor.putInt("sort", 1);
                editor.commit();
                onResume();
                break;
            case R.id.sort2:    // 정렬 기준 : 기한
                editor.remove("sort");
                editor.putInt("sort", 2);
                editor.commit();
                onResume();
                break;
            case R.id.sort3:    // 정렬 기준 : 완료여부
                editor.remove("sort");
                editor.putInt("sort", 3);
                editor.commit();
                onResume();
                break;
            case R.id.sort4:    // 정렬 기준 : 등록 날짜
                editor.remove("sort");
                editor.putInt("sort", 4);
                editor.commit();
                onResume();
                break;
            case R.id.sort5:    // 정렬 기준 : 알람 날짜
                editor.remove("sort");
                editor.putInt("sort", 5);
                editor.commit();
                onResume();
                break;
            case R.id.item_menu5:   // 목록 삭제
                Toast.makeText(mContext, "test5", Toast.LENGTH_SHORT).show();
                break;
            default:
                break;
        }

        return true;
    }


    private void loadCheckBox() {
        monCB = howRepeatView.findViewById(R.id.monday_check_box);
        tueCB = howRepeatView.findViewById(R.id.tuesday_check_box);
        wedCB = howRepeatView.findViewById(R.id.wednesday_check_box);
        thurCB = howRepeatView.findViewById(R.id.thursday_check_box);
        friCB = howRepeatView.findViewById(R.id.friday_check_box);
        satCB = howRepeatView.findViewById(R.id.saturday_check_box);
        sunCB = howRepeatView.findViewById(R.id.sunday_check_box);
    }

    private void loadAndSetListenerMenuLayout() {
        firstMenuLayout = findViewById(R.id.first_menu_layout);
        secondMenuLayout = findViewById(R.id.second_menu_layout);
        thirdMenuLayout = findViewById(R.id.third_menu_layout);
        firstMenuLayout.setOnClickListener(clickListener);
        firstMenuLayout.setOnTouchListener(touchListener);
        secondMenuLayout.setOnClickListener(clickListener);
        secondMenuLayout.setOnTouchListener(touchListener);
        thirdMenuLayout.setOnClickListener(clickListener);
        thirdMenuLayout.setOnTouchListener(touchListener);
    }

    private void initSettings() {
        textViewInit();
        initStrings();
        toDoContentInit();
        initCheckBox();
        setUnclikedStar();
        initBoolean();
        initAlarmTime();
    }

    private void initAlarmTime() {
        alarmYear = "";
        alarmMonth = "";
        alarmDate = "";
        alarmHour = "";
        alarmMin = "";
        secondMenuTextView.setTextSize(13);
    }

    private void initCheckBox() {
        monCB.setChecked(false);
        tueCB.setChecked(false);
        wedCB.setChecked(false);
        thurCB.setChecked(false);
        friCB.setChecked(false);
        satCB.setChecked(false);
        sunCB.setChecked(false);
        repeatDow = "";
        toDoDayList.clear();
    }

    public String getDOW(String year, String month, String day, int mode) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date date = sdf.parse(year+month+day);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        String DOW = getTranslatedKoreanDow(String.valueOf(calendar.get(Calendar.DAY_OF_WEEK)), mode);

        return DOW;
    }

    private void setThirdTextView() {
        if(howRepeatUnit == 1) {
            thirdMenuTextView.setText(Integer.parseInt(howRepeatEditText.getText().toString()) + "일마다");
        }else if(howRepeatUnit == 7) {
            if(toDoDayList.isEmpty() || howRepeatEditText.getText().toString().equals("0")) {
                toDoDayList.clear();
                thirdMenuTextView.setText("반복 안함");
            }else{
                StringBuilder textContent = new StringBuilder(Integer.parseInt(howRepeatEditText.getText().toString()) +"주마다 ");
                Iterator<String> iterator = toDoDayList.iterator();

                while(iterator.hasNext()) {
                    textContent.append(iterator.next() + ", ");
                }
                textContent.delete(textContent.length()-2, textContent.length()-1);
                thirdMenuTextView.setText(textContent);
            }
        }else if(howRepeatUnit == 30) {
            thirdMenuTextView.setText(Integer.parseInt(howRepeatEditText.getText().toString()) + "개월마다");
        }else if(howRepeatUnit == 365) {
            thirdMenuTextView.setText(Integer.parseInt(howRepeatEditText.getText().toString()) + "년마다");
        }

    }



    /*                   */
     /*   others methods  */
    /*                   */

/*    private View createTabView(String tabName, int idx) {

        String mTabName = tabName;

        View tabView = tabView = LayoutInflater.from(mContext).inflate(R.layout.my_custom_tab, null);;
        ImageView imageView = (ImageView) tabView.findViewById(R.id.tab_image_view);
        TextView textView = (TextView) tabView.findViewById(R.id.tab_name_text_view);

        switch (idx){
            case 0:
                textView.setText(tabName);
                imageView.setImageResource(R.drawable.ic_launcher_foreground); // first tab image
                break;
            case 1:
                textView.setText(tabName);
                imageView.setImageResource(R.drawable.ic_launcher_foreground); // second tab image
                break;
            case 2:
                textView.setText(tabName);
                imageView.setImageResource(R.drawable.calender_icon); // third tab image
                break;
            case 3:
                textView.setText(tabName);
                imageView.setImageResource(R.drawable.calender_icon); // third tab image
                break;
        }
        return tabView;
    }*/

    private void setClickedStar() {
        favoriteImageView.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.favorite_image_check));
        favoriteImageView.setImageResource(R.drawable.favorite_icon);
        isFavorite = true;
    }

    private void setUnclikedStar() {
        favoriteImageView.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.favorite_image_uncheck));
        favoriteImageView.setImageResource(R.drawable.empty_favorite_icon);
        isFavorite = false;
    }


    private void dbInsert(String toDoContent, boolean isFavorite, String dayToDo, String repeatDOW,
                          String created, String howRepeat, boolean isClear, String alarmYear, String alarmMonth, String alarmDate
    , String alarmHour, String alarmMin, String repeatText, String howRepeatUnit, String memo, String forSeparatingCreated) {

        DBHelper dbHelper = new DBHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        String favoriteChk;
        String clearChk;


        if(isFavorite == true) {
            favoriteChk = "1";
        }else{
            favoriteChk = "0";
        }

        if(isClear == true) {
            clearChk = "1";
        }else {
            clearChk = "0";
        }


        db.execSQL("INSERT INTO todo_table (content, dayToDo, repeatDOW, created, howRepeat, repeatMonth, repeatDate, isFavorite, isclear," +
                        " alarmYear, alarmMonth, alarmDate, alarmHour, alarmMin, repeatText, howRepeatUnit, memo, forSeparatingCreated) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                new String[] {toDoContent, dayToDo, repeatDOW, created, howRepeat, repeatMonth, repeatDay, favoriteChk, clearChk,
                        alarmYear, alarmMonth, alarmDate, alarmHour, alarmMin, repeatText, howRepeatUnit, memo, forSeparatingCreated});

        db.close();

    }

    public String setDeadlineDOW(String when) {
        String dow = "";
        Calendar cal = Calendar.getInstance();
        int dayIndex = cal.get(Calendar.DAY_OF_WEEK) - 1;       // cal.get = 일요일 : 1  ~   토요일 : 7

        // dayIndex = 일요일 : 0 ~   토요일 : 6
        // weekDay = {"일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일"}
        /*               0         1        2        3         4        5        6         */

        if(when.equals("오늘")) {
            dow = weekDay[dayIndex];
        } else if(when.equals("내일")) {
            dow = weekDay[(dayIndex+1) % 7];
        } else if(when.equals("다음주")) {
            dow = weekDay[dayIndex];
        }
        return dow;
    }

    private void initBoolean() {
        isDaySet = false;
        isAlarmSet = false;
        isRepeatSet = false;
    }

    private void addToDoDOWToArrayList() {
        if(monCB.isChecked()) {
            toDoDayList.add("월요일");
        }if(tueCB.isChecked()) {
            toDoDayList.add("화요일");
        }if(wedCB.isChecked()) {
            toDoDayList.add("수요일");
        }if(thurCB.isChecked()) {
            toDoDayList.add("목요일");
        }if(friCB.isChecked()) {
            toDoDayList.add("금요일");
        }if(satCB.isChecked()) {
            toDoDayList.add("토요일");
        }if(sunCB.isChecked()) {
            toDoDayList.add("일요일");
        }
    }

    private void alarmTimeSet(String hour, String minute) {
        if(hour.equals("24") && minute.equals("00")){
            secondMenuTextView.setText("금일 자정 알림");
        }
        secondMenuTextView.setText(hour + "시 " + minute + "분 푸시알림");
        secondMenuTextView.setTextSize(12);
    }

    /*@Override
    public void onFragmentInteraction(Uri uri) {

    }*/

    @SuppressLint("RestrictedApi")
    @Override
    public void onBackPressed() {

        View view;
        AlertDialog.Builder builder;
        final AlertDialog dialog;

        if(drawerLayout.isDrawerOpen(drawerView)){
            drawerLayout.closeDrawer(drawerView);
            return;
        }

        if(addLinearLayout.getVisibility() == View.GONE && isKeyBoardView == false) {

            view = LayoutInflater.from(MainActivity.this).inflate(R.layout.custom_toast_back_press, null);
            builder = new AlertDialog.Builder(MainActivity.this);
            builder.setView(view);
            builder.setCancelable(false);
            builder.setPositiveButton("종료", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });
            builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            });
            dialog = builder.create();
            dialog.setContentView(R.layout.custom_toast_back_press);
            dialog.setCanceledOnTouchOutside(false);

            if(dialog.isShowing()) {                    // dialog가 열려있는 경우 : 앱을 종료해야함
                // the problem is clear.
            }else {
                dialog.show();
            }
        }
        if(isKeyBoardView) {
            isKeyBoardView = false;
        }
        //super.onBackPressed();
    }






    @Override
    public void onResume() { //onStart는 onCreate 다음에 실행 (Activity가 보여지기 직전에 실행 됌)
        super.onResume();

        todayYear = sdf.format(new Date()).split("-")[0];
        todayMonth = sdf.format(new Date()).split("-")[1];
        todayDay = sdf.format(new Date()).split("-")[2];

        doneDataset.clear();
        notDoneDataset.clear();

        DBHelper dbHelper = new DBHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        ToDoData header = new ToDoData();
        header.setToDoContent("일정");
        header.setViewType(VIEW_TYPE_TITLE);
        notDoneDataset.add(header);


        // 미완료 일정 목록

        Cursor cursor = null;

        switch (setting.getInt("sort", 0)){
            case 0: // 중요도
                cursor = db.rawQuery("select * from todo_table order by CAST(isFavorite AS int) asc", new String[0]);
                break;
            case 1: // 기한
                cursor = db.rawQuery("select * from todo_table order by CAST(dayToDo AS int) asc", new String[0]);
                break;
            case 2: // 완료여부
                cursor = db.rawQuery("select * from todo_table order by CAST(isClear AS int) asc", new String[0]);
                break;
            case 3: // 등록날짜
                cursor = db.rawQuery("select * from todo_table order by CAST(created AS int) asc", new String[0]);
                break;
            case 4: // 알람 설정여부
                cursor = db.rawQuery("select * from todo_table order by CAST(alarmYear AS int), " +
                        "CAST(alarmMonth AS int), alarmDate, alarmHour, alarmMin asc", new String[0]);
                break;
            default:
                cursor = db.rawQuery("select * from todo_table where isclear=?",
                        new String[] {"0"});
        }

        while(cursor.moveToNext()) {
            ToDoData data = new ToDoData();

            data.setToDoContent(cursor.getString(1));
            data.setToDoDay((cursor.getString(2))); //format : mYear-mMonth-mDay
            data.setRepeatDow(cursor.getString(3)); // format : x요일y요일z요일 or x요일y요일
            data.setCreated(cursor.getString(4));
            data.setHowRepeat(cursor.getString(5));
            data.setRepeatMonth(cursor.getString(6));
            data.setRepeatDate(cursor.getString(7));
            data.setIsFavroite(Integer.parseInt(cursor.getString(8)));
            data.setIsClear(Integer.parseInt(cursor.getString(9)));
            data.setAlarmYear(cursor.getString(10));
            data.setAlarmMonth(cursor.getString(11));
            data.setAlarmDate(cursor.getString(12));
            data.setAlarmHour(cursor.getString(13));
            data.setAlarmMin(cursor.getString(14));
            data.setRepeatText(cursor.getString(15));
            data.setHowRepeatUnit(Integer.parseInt(cursor.getString(16)));
            data.setMemo((cursor.getString(17)));
            data.setForSeparatingCreated((cursor.getString(18)));
            data.setViewType(VIEW_TYPE_ITEM);
            //int dDay = calculateDDay(Integer.parseInt(cursor.getString(2).split("-")[0]), Integer.parseInt(cursor.getString(2).split("-")[1]), Integer.parseInt(cursor.getString(2).split("-")[2]));
            data.setdDay(0);

            notDoneDataset.add(data);
        }

        notDoneAdapter.notifyDataSetChanged();
        db.close();

    }

    ItemTouchHelper.Callback touchHelperCallback = new ItemTouchHelper.Callback() {
        @Override
        public int getMovementFlags(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder) {
            int dragFlags = 0;
            int swipeFlags = ItemTouchHelper.START | ItemTouchHelper.END;
            return makeMovementFlags(dragFlags, swipeFlags);
        }

        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {

        }
    };


    @SuppressLint("RestrictedApi")
    public void hideAddLayout() {

        imm.hideSoftInputFromWindow(enterToDoEditText.getWindowToken(), 0);

        Thread hideThread = new Thread(new Runnable() {
            @Override
            public void run() {
                //addLinearLayout.setAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.add_layout_invisible));
                fab.setAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_visible));
                addLinearLayout.setAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.add_layout_invisible));
            }
        });
        hideThread.start();
        addLinearLayout.setVisibility(View.GONE);
        fab.setVisibility(View.VISIBLE);
    }

    private void initStrings() {
        selectedYear = ""; selectedMonth = ""; selectedDay = "";                                    // 일정 일자
        howRepeat = ""; howRepeatDayString = "";
        alarmHour = ""; alarmMin = "";
        repeatMonth = ""; repeatDay = ""; repeatDow = "";
        repeatText = "";
        isAlarmSet = false;
        isDaySet = false;
        isRepeatSet = false;
        dowStringBuilder.setLength(0);
        forSeparatingCreated = "";
    }

    private void initAddView() {
        textViewInit();
        favoriteImageView.setImageResource(R.drawable.empty_favorite_icon);
        isFavorite = false;

        firstMenuTextView.setText("기한 설정");
        secondMenuTextView.setText("알림 설정");
        thirdMenuTextView.setText("반복 설정");

        firstMenuTextView.setTextSize(13);
        secondMenuTextView.setTextSize(13);
        thirdMenuTextView.setTextSize(13);

        howRepeatSpinner.setSelection(0);
        howRepeatUnit = 1;
        howRepeatDayInt = 0;
        selectedYear = ""; selectedMonth = ""; selectedDay = "";
        alarmHour = ""; alarmMin = "";
        howRepeat = ""; howRepeatDayString = "";


    }

    private void textViewInit() {
        enterToDoEditText.setText("");
    }

    private void toDoContentInit() {
        toDoContent = "";
    }



    public interface ClickListener {
        void onClick(View view, int position);
        void onLongClick(View view, int position);
    }

    public static class RecyclerTouchListener implements RecyclerView.OnItemTouchListener {

        private GestureDetector gestureDetector;
        private ClickListener clickListener;

        public RecyclerTouchListener(Context context, final RecyclerView recyclerView, final MainActivity.ClickListener clickListener) {
            this.clickListener = clickListener;

            gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {
                    View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                    if (child != null && clickListener != null) {
                        clickListener.onLongClick(child, recyclerView.getChildAdapterPosition(child));
                    }
                }
            });
        }


        @Override
        public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
            View child = rv.findChildViewUnder(e.getX(), e.getY());
            if (child != null && clickListener != null && gestureDetector.onTouchEvent(e)) {
                clickListener.onClick(child, rv.getChildAdapterPosition(child));
            }
            return false;
        }

        @Override
        public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

        }

        @Override
        public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

        }
    }



    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == Activity.RESULT_OK) {
            switch (requestCode) {
                //EditActivity로 요청할 때 보낸 CODE
                case REQUEST_TO_EDIT_ACTIVITY_CODE:
                    int newYear, newMonth, newDay;

                    Bundle editBundle = data.getExtras();

                    ToDoData newData = new ToDoData();

                    newYear = editBundle.getInt("year");
                    newMonth = editBundle.getInt("month");
                    newDay = editBundle.getInt("day");
                    String newSec = editBundle.getString("sec");

                    newData.setToDoContent(editBundle.getString("content"));
                    newData.setToDoDay(editBundle.getString("dayString"));
                    //newData.setPriority(editBundle.getInt("priority"));
                    newData.setdDay(calculateDDay(newYear, newMonth, newDay));
                    newData.setCreated(newSec);

                    notDoneDataset.set(editPosition, newData);
                    notDoneAdapter.notifyItemChanged(editPosition);
                    break;
            }
        }
    }

    DrawerLayout.DrawerListener drawerListener = new DrawerLayout.DrawerListener() {
        @Override
        public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {

        }

        @Override
        public void onDrawerOpened(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerClosed(@NonNull View drawerView) {

        }

        @Override
        public void onDrawerStateChanged(int newState) {

        }
    };


    public int calculateDDay(int _year, int _month, int _day) {

        Calendar today = Calendar.getInstance(); // 오늘 날짜
        Calendar dDay = Calendar.getInstance(); // d - Day 날짜

        dDay.set(_year, _month - 1, _day); // d-day 날짜 셋팅

        long _dDay = dDay.getTimeInMillis() / 86400000; // 8640000 = 24 * 60 * 60 * 1000 milliseconds
        long _today = today.getTimeInMillis() / 86400000;
        int count = (int) (_dDay - _today); // d - Day

        return count;
    }
}

